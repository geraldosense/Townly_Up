#!/bin/bash
# Townly Up — duplo clique para instalar (1.ª vez) e arrancar o servidor.
cd "$(dirname "$0")" || exit 1
echo "== Townly Up =="

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERRO: o Python 3 não está instalado. Instale em https://www.python.org/downloads/"
  read -r -p "Carregue Enter para fechar..."; exit 1
fi

if [ ! -d .venv ]; then
  echo "-> A criar o ambiente virtual (.venv)..."
  python3 -m venv .venv || { echo "ERRO ao criar o .venv"; read -r -p "Enter para fechar..."; exit 1; }
fi
source .venv/bin/activate

echo "-> A instalar dependências (Flask, Pillow, pytest)..."
python -m pip install -q --upgrade pip
python -m pip install -q -r requirements.txt || { echo "ERRO na instalação (verifique a internet)"; read -r -p "Enter para fechar..."; exit 1; }

echo "-> A preparar a base de dados (dados de demonstração na 1.ª vez)..."
flask --app app seed-demo >/dev/null 2>&1 && echo "   Dados de demonstração criados." || echo "   Base de dados já existente — mantida."

if [ ! -f static/data/freguesias_fundao.geojson ]; then
  echo "-> A descarregar os limites das freguesias (CAOP / DGT)..."
  flask --app app freguesias || echo "   (Sem o mapa das freguesias por agora — o resto funciona.)"
fi

PORT=8000
echo ""
echo "Servidor em: http://127.0.0.1:$PORT   (Ctrl+C para parar)"
echo "Contas: ana@demo.pt / carlos@demo.pt (munícipes) · rui@demo.pt (admin) · palavra-passe Fundao2026"
echo ""
(sleep 2; open "http://127.0.0.1:$PORT") &
flask --app app run --debug --port "$PORT"
